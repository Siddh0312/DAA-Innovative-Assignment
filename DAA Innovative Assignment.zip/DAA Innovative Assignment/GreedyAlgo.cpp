#include<bits/stdc++.h>
using namespace std;

struct Storage {
    int itemID;
    int spaceAvailable;

    Storage(int id, int space) : itemID(id), spaceAvailable(space) {}
};

bool compareStoragePlaces(Storage a, Storage b) {
    return a.spaceAvailable > b.spaceAvailable;
}

void allocateSpace(vector<Storage> &storagePlace, int itemSize) {
    sort(storagePlace.begin(), storagePlace.end(), compareStoragePlaces);

    for(auto& unit : storagePlace) {
        if(unit.spaceAvailable > itemSize) {
            unit.spaceAvailable -= itemSize;
            cout<<"Space allocated to the item with the ID "<<unit.itemID << "!" <<endl;
            return;
        }
    }
    cout<<"Not enough space available";
}
