#include<iostream>
#include "BST.cpp"
#include "GreedyAlgo.cpp"
#include "Dijkstra.cpp"
#include "PriorityQueue.cpp"
#include "DFS.cpp"

int main() {
    BST bstWarehouse;
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 1, "Cricket Kit");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 2, "Books");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 3, "Football");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 4, "Kitchen Appliances");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 5, "Wood");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 6, "Steel");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 7, "Rubber Bands");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 8, "Phones");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 9, "Laptops");
    bstWarehouse.root = bstWarehouse.insert(bstWarehouse.root, 10, "Rings");
    cout<<"Items in inorder are: "<<endl;
    bstWarehouse.inorder(bstWarehouse.root);

     // 2. Greedy Algorithm for space allocation
    vector<Storage> storageUnits;
    storageUnits.emplace_back(1, 100);
    storageUnits.emplace_back(2, 50);
    storageUnits.emplace_back(3, 150);
    storageUnits.emplace_back(4, 75);   
    int itemSize = 80;
    cout << "\nAllocating space for an item of size " << itemSize << ":" << endl;
    allocateSpace(storageUnits, itemSize);

    // 3. Priority Queue for shipping items based on priority
    priority_queue<Item> shippingQueue;
    addItemToQueue(shippingQueue, 5, "High Priority Item");
    addItemToQueue(shippingQueue, 3, "Medium Priority Item");
    addItemToQueue(shippingQueue, 1, "Low Priority Item");
    cout << "\nShipping items from the priority queue:" << endl;
    shipItemFromQueue(shippingQueue);
    shipItemFromQueue(shippingQueue);

    // 4. Depth-First Search (DFS) for exploring warehouse layout
    Warehouse warehouseGraph(6); // Initialize graph with 6 locations
    warehouseGraph.addEdge(0, 1);
    warehouseGraph.addEdge(0, 2);
    warehouseGraph.addEdge(1, 3);
    warehouseGraph.addEdge(1, 4);
    warehouseGraph.addEdge(2, 5);
    std::cout << "\nExploring warehouse starting from location 0 using DFS:" << endl;
    warehouseGraph.dfsOfGraph(0);

    // 5. Dijkstra’s Algorithm for shortest path
    vector<vector<pair<int, int> > > adjList(6); // 6 nodes
    adjList[0].emplace_back(1, 10);
    adjList[0].emplace_back(2, 5);
    adjList[1].emplace_back(3, 2);
    adjList[2].emplace_back(1, 3);
    adjList[2].emplace_back(3, 9);
    adjList[3].emplace_back(4, 4);
    vector<int> dist(6, INT_MAX);
    int source = 0;
    cout << "\nCalculating shortest paths from location " << source << " using Dijkstra's algorithm:" << endl;
    dijkstra(source, adjList, dist);

    return 0;
}