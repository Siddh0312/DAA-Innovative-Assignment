#include <iostream>
#include <vector>
#include <queue>
#include <climits>
using namespace std;

void dijkstra(int S, vector<vector<pair<int, int> > > &adjList, vector<int> &distance) {
    priority_queue<pair<int, int>,vector<pair<int, int> >,greater<pair<int, int> > > pq;
    int V = adjList.size();
    distance.assign(V, INT_MAX); 
    distance[S] = 0; 
    pq.push(make_pair(0, S));

    while(!pq.empty()) {
        int dis = pq.top().first;
        int node = pq.top().second;
        pq.pop();

        if (dis > distance[node]) continue;

        for(auto it : adjList[node]) {
            int adjNode = it.first;
            int edgeWeight = it.second;

            if(dis + edgeWeight < distance[adjNode]) {
                distance[adjNode] = dis + edgeWeight;
                pq.push(make_pair(distance[adjNode], adjNode));
            }
        }
    }
    for (size_t i = 0; i < distance.size(); ++i) {
        std::cout << "Distance from " << S << " to " << i << ": " << distance[i] << std::endl;
    }
}