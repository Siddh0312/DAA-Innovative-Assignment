#include<bits/stdc++.h>
using namespace std;

struct Item{
    int priority;
    string itemName;
    bool operator<(const Item& other) const { 
        return priority < other.priority; 
    }
};

void addItemToQueue(priority_queue<Item> &queue, int priority, string itemName) {
    Item newItem;
    newItem.priority = priority;
    newItem.itemName = itemName;
    queue.push(newItem);
}

void shipItemFromQueue(priority_queue<Item> &queue) {
    if(queue.empty()) {
        cout<<"No items to ship!"<<endl;
    }
    
    Item newItem = queue.top();
    queue.pop();
    cout<<"Shipped Item "<< newItem.itemName<< " with priority "<< newItem.priority<<"!"<<endl;
}