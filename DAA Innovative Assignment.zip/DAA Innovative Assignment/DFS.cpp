#include<bits/stdc++.h>
using namespace std;

class Warehouse {
    public:
    vector<vector<int> > adjList;
    int nodes;

    Warehouse(int nodes) : nodes(nodes) {
        adjList.resize(nodes);
    }

    void addEdge(int x, int y) {
        adjList[x].push_back(y);
        adjList[y].push_back(x);
    }

    void DFS(int node, vector<int> vis) {
        vis[node] = 1;
        cout<<"Visiting Node "<<node<<endl;
        for(auto it: adjList[node]) {
            if(!vis[it]) {
                DFS(it, vis);
            }
        }
    }

    void dfsOfGraph(int startLocation) {
        vector<int> vis(nodes,0);
        DFS(startLocation, vis);
    }
};
    