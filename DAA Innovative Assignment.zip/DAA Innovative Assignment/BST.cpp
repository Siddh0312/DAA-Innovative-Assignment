#include<bits/stdc++.h>
using namespace std;

struct Node {
    int itemID;
    string itemName;
    Node* left;
    Node* right;

    Node(int id, std::string name) : itemID(id), itemName(name), left(nullptr), right(nullptr) {}
};

class BST {
    public: 
    Node* root;
    BST() : root(nullptr) {}

    Node* insert(Node* root, int itemID, string itemName) {
        if(root == NULL) {
            return new Node(itemID, itemName);
        }
        if(itemID < root->itemID) {
            root->left = insert(root->left, itemID, itemName);
        } else {
            root->right = insert(root->right, itemID, itemName);
        }
        return root;
    }

    Node* search(Node* root, int itemID) {
        if(root == NULL || (root->itemID == itemID)) {
            return root;
        }
        if(itemID < root->itemID) {
            return search(root->left, itemID);
        } else {
            return search(root->right, itemID);
        }
    }

    void inorder(Node* root) {
        if(root == NULL) {
            return;
        }
        inorder(root->left);
        cout<<root->itemID<< " "<<root->itemName<<endl;
        inorder(root->right);
    }
};